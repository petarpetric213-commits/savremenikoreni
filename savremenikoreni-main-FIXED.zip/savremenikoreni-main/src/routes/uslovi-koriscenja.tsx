import { createFileRoute } from '@tanstack/react-router'
import { LegalPage, LegalH2, LegalP } from '@/components/LegalPage'

export const Route = createFileRoute('/uslovi-koriscenja')({
  component: UsloviPage,
})

// NOTE FOR THE SITE OWNER: this is generic template text, not legal advice.
// Replace the bracketed placeholders with your real business details and,
// ideally, have it reviewed against the Zakon o zaštiti potrošača / Zakon o
// elektronskoj trgovini before relying on it commercially.

function UsloviPage() {
  return (
    <LegalPage label="Pravne informacije" title="Uslovi korišćenja">
      <LegalP>
        Ovi uslovi korišćenja regulišu odnos između sajta Savremeni Koreni
        (u daljem tekstu: „mi", „prodavac") i posetitelja/kupaca (u daljem
        tekstu: „vi", „kupac") koji koriste sajt savremenikoreni.netlify.app.
        Korišćenjem sajta i slanjem porudžbine smatra se da prihvatate ove
        uslove.
      </LegalP>

      <LegalH2>Ko stoji iza sajta</LegalH2>
      <LegalP>
        Savremeni Koreni je brend ručno rađenih torbica i pletenih kreacija.
        Kontakt: savremenikoreni@gmail.com, telefon 060 331 8319.
        [Ovde dodati pun naziv vlasnika/radnje i PIB/MB ako je delatnost
        registrovana — obavezno za prodaju robe potrošačima u Srbiji.]
      </LegalP>

      <LegalH2>Proizvodi i cene</LegalH2>
      <LegalP>
        Svi proizvodi su ručno rađeni, zbog čega mogu postojati sitne razlike
        u boji, teksturi ili dimenzijama u odnosu na fotografije — to je
        prirodna posledica ručne izrade i ne smatra se nedostatkom. Cene su
        prikazane u dinarima (RSD) i ne uključuju eventualne troškove
        dostave, koji se posebno naznačuju pri porudžbini.
      </LegalP>

      <LegalH2>Porudžbina</LegalH2>
      <LegalP>
        Porudžbina se smatra prihvaćenom kada je kupac popuni i pošalje
        formu za porudžbinu na sajtu. Plaćanje se vrši pouzećem prilikom
        preuzimanja ili po dogovoru putem WhatsApp-a/email-a. Zadržavamo
        pravo da kontaktiramo kupca radi potvrde detalja ili da otkažemo
        porudžbinu u slučaju nedostupnosti materijala.
      </LegalP>

      <LegalH2>Posebne (custom) porudžbine</LegalH2>
      <LegalP>
        Za komade prilagođene posebnim zahtevima kupca (izbor boje,
        materijala, dimenzija) detalji se usaglašavaju direktno putem
        kontakt forme, email-a ili WhatsApp-a pre početka izrade.
      </LegalP>

      <LegalH2>Intelektualna svojina</LegalH2>
      <LegalP>
        Sadržaj sajta (tekstovi, fotografije, dizajn) je vlasništvo
        Savremeni Koreni i ne može se koristiti ili reprodukovati bez
        odobrenja.
      </LegalP>

      <LegalH2>Izmene uslova</LegalH2>
      <LegalP>
        Zadržavamo pravo da povremeno ažuriramo ove uslove. Aktuelna verzija
        je uvek dostupna na ovoj stranici.
      </LegalP>

      <LegalH2>Kontakt</LegalH2>
      <LegalP>
        Za sva pitanja u vezi sa ovim uslovima, pišite na
        savremenikoreni@gmail.com.
      </LegalP>
    </LegalPage>
  )
}
