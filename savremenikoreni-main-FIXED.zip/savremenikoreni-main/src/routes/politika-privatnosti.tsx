import { createFileRoute } from '@tanstack/react-router'
import { LegalPage, LegalH2, LegalP } from '@/components/LegalPage'

export const Route = createFileRoute('/politika-privatnosti')({
  component: PrivatnostPage,
})

// NOTE FOR THE SITE OWNER: generic template, not legal advice. Review
// against the Zakon o zaštiti podataka o ličnosti before relying on it.

function PrivatnostPage() {
  return (
    <LegalPage label="Pravne informacije" title="Politika privatnosti">
      <LegalP>
        Vaša privatnost nam je važna. Ova politika objašnjava koje podatke
        prikupljamo kada koristite sajt Savremeni Koreni i kako ih koristimo.
      </LegalP>

      <LegalH2>Koje podatke prikupljamo</LegalH2>
      <LegalP>
        Kada popunite formu za porudžbinu, kontakt formu ili se prijavite na
        newsletter, prikupljamo podatke koje sami unesete: ime, email
        adresu, broj telefona, adresu za dostavu i sadržaj poruke. Ne
        prikupljamo podatke o plaćanju, jer plaćanje ide direktno pouzećem
        ili dogovorom — sajt ne čuva podatke o platnim karticama.
      </LegalP>

      <LegalH2>Zašto prikupljamo te podatke</LegalH2>
      <LegalP>
        Podatke koristimo isključivo da bismo: obradili i isporučili vašu
        porudžbinu, odgovorili na vaša pitanja, i (ako se prijavite) poslali
        vam obaveštenja o novim kolekcijama. Ne prodajemo i ne ustupamo vaše
        podatke trećim licima u marketinške svrhe.
      </LegalP>

      <LegalH2>Gde se podaci čuvaju</LegalH2>
      <LegalP>
        Forme na sajtu se obrađuju preko Netlify Forms infrastrukture, a
        email obaveštenja se šalju preko servisa Resend. Oba servisa
        funkcionišu kao obrađivači podataka u ime Savremeni Koreni.
      </LegalP>

      <LegalH2>Vaša prava</LegalH2>
      <LegalP>
        Imate pravo da zatražite uvid, izmenu ili brisanje svojih podataka
        koje smo prikupili. Zahtev možete poslati na
        savremenikoreni@gmail.com.
      </LegalP>

      <LegalH2>Kolačići (cookies)</LegalH2>
      <LegalP>
        Sajt koristi lokalno čuvanje podataka u vašem pretraživaču
        (localStorage) samo da bi pamtio sadržaj vaše korpe između posета —
        ovi podaci ostaju na vašem uređaju i ne šalju se nama.
      </LegalP>

      <LegalH2>Kontakt</LegalH2>
      <LegalP>
        Pitanja u vezi sa privatnošću podataka možete poslati na
        savremenikoreni@gmail.com.
      </LegalP>
    </LegalPage>
  )
}
