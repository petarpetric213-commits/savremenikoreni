import type { Context } from '@netlify/functions'

/**
 * Triggered automatically by Netlify whenever any registered form is
 * submitted (porudzbina / kontakt / newsletter). Sends notification emails
 * through Resend.
 *
 * Email sending is enabled by setting the RESEND_API_KEY environment variable
 * in the Netlify project settings. Without it, submissions are still stored
 * by Netlify Forms (visible + notifiable via the Netlify UI) — this function
 * simply logs and exits.
 */

const OWNER_EMAIL = 'savremenikoreni@gmail.com'
const FROM_EMAIL = process.env.EMAIL_FROM ?? 'Savremeni Koreni <onboarding@resend.dev>'

interface FormPayload {
  form_name?: string
  data?: Record<string, string>
}

async function sendEmail(apiKey: string, to: string, subject: string, html: string, replyTo?: string) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, html, reply_to: replyTo }),
  })

  if (!res.ok) {
    console.error('Resend error', res.status, await res.text())
  }
  return res.ok
}

function esc(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

async function handlePorudzbina(apiKey: string, data: Record<string, string>) {
  const ime = data.ime ?? ''
  const prezime = data.prezime ?? ''
  const fullName = `${ime} ${prezime}`.trim() || 'kupac'
  const stavke = (data.porudzbina ?? '')
    .split('\n')
    .filter(Boolean)
    .map((line) => `<li>${esc(line)}</li>`)
    .join('')

  if (data.email) {
    const buyerHtml = `
      <div style="font-family:Georgia,serif;color:#1E3A2F;max-width:560px;margin:0 auto;">
        <h1 style="color:#1E3A2F;">Hvala na porudžbini, ${esc(ime) || 'dragi kupče'}!</h1>
        <p style="color:#4A4A4A;line-height:1.7;">
          Vaša porudžbina kod <strong>Savremeni Koreni</strong> je uspešno primljena.
          Javićemo vam se u najkraćem roku radi dogovora o dostavi i plaćanju.
        </p>
        <h3 style="color:#BF9B5E;">Vaša porudžbina</h3>
        <ul style="color:#4A4A4A;line-height:1.7;">${stavke || '<li>—</li>'}</ul>
        <p style="color:#1E3A2F;font-weight:bold;">Ukupno: ${esc(data.ukupno ?? '')}</p>
        <p style="color:#6B6258;font-size:13px;margin-top:24px;">
          Ako imate pitanja, odgovorite na ovaj email ili nas kontaktirajte na ${OWNER_EMAIL}.
        </p>
      </div>`
    await sendEmail(apiKey, data.email, 'Hvala na porudžbini — Savremeni Koreni', buyerHtml, OWNER_EMAIL)
  }

  const ownerHtml = `
    <div style="font-family:Arial,sans-serif;color:#1A1A1A;max-width:560px;margin:0 auto;">
      <h2>Nova porudžbina</h2>
      <p><strong>Kupac:</strong> ${esc(fullName)}</p>
      <p><strong>Email:</strong> ${esc(data.email ?? '')}</p>
      <p><strong>Telefon:</strong> ${esc(data.telefon ?? '')}</p>
      <p><strong>Adresa:</strong> ${esc(data.adresa ?? '')}, ${esc(data.grad ?? '')}</p>
      <p><strong>Napomena:</strong> ${esc(data.napomena ?? '') || '—'}</p>
      <h3>Stavke</h3>
      <ul>${stavke || '<li>—</li>'}</ul>
      <p><strong>Ukupno:</strong> ${esc(data.ukupno ?? '')}</p>
    </div>`
  await sendEmail(apiKey, OWNER_EMAIL, `Nova porudžbina — ${fullName}`, ownerHtml, data.email)
}

async function handleKontakt(apiKey: string, data: Record<string, string>) {
  const ime = data.ime ?? 'posetilac'

  // Notify the owner with the message + visitor's contact details
  const ownerHtml = `
    <div style="font-family:Arial,sans-serif;color:#1A1A1A;max-width:560px;margin:0 auto;">
      <h2>Nova poruka sa kontakt forme</h2>
      <p><strong>Ime:</strong> ${esc(ime)}</p>
      <p><strong>Email:</strong> ${esc(data.email ?? '')}</p>
      <p><strong>Telefon:</strong> ${esc(data.telefon ?? '') || '—'}</p>
      <h3>Poruka</h3>
      <p style="white-space:pre-wrap;">${esc(data.poruka ?? '')}</p>
    </div>`
  await sendEmail(apiKey, OWNER_EMAIL, `Nova poruka — ${esc(ime)}`, ownerHtml, data.email)

  // Confirmation back to the visitor
  if (data.email) {
    const visitorHtml = `
      <div style="font-family:Georgia,serif;color:#1E3A2F;max-width:560px;margin:0 auto;">
        <h1 style="color:#1E3A2F;">Hvala na poruci, ${esc(ime)}!</h1>
        <p style="color:#4A4A4A;line-height:1.7;">
          Primili smo vašu poruku i javićemo se u roku od 24 sata.
        </p>
        <p style="color:#6B6258;font-size:13px;margin-top:24px;">
          Ako je hitno, slobodno nas kontaktirajte i direktno na ${OWNER_EMAIL}.
        </p>
      </div>`
    await sendEmail(apiKey, data.email, 'Hvala na poruci — Savremeni Koreni', visitorHtml, OWNER_EMAIL)
  }
}

async function handleNewsletter(apiKey: string, data: Record<string, string>) {
  if (!data.email) return
  const ownerHtml = `
    <div style="font-family:Arial,sans-serif;color:#1A1A1A;max-width:560px;margin:0 auto;">
      <h2>Nova prijava na newsletter</h2>
      <p><strong>Email:</strong> ${esc(data.email)}</p>
    </div>`
  await sendEmail(apiKey, OWNER_EMAIL, 'Nova prijava na newsletter', ownerHtml, data.email)
}

export default async (req: Request, _context: Context) => {
  let formName = ''
  let data: Record<string, string> = {}
  try {
    const body = (await req.json()) as { payload?: FormPayload }
    formName = body.payload?.form_name ?? ''
    data = body.payload?.data ?? {}
  } catch (err) {
    console.error('Could not parse submission payload', err)
    return new Response('Bad payload', { status: 200 })
  }

  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) {
    console.log(`RESEND_API_KEY not set — skipping email send. Form "${formName}" data:`, data)
    return new Response('OK (email disabled)', { status: 200 })
  }

  switch (formName) {
    case 'porudzbina':
      await handlePorudzbina(apiKey, data)
      break
    case 'kontakt':
      await handleKontakt(apiKey, data)
      break
    case 'newsletter':
      await handleNewsletter(apiKey, data)
      break
    default:
      console.log(`Unknown form "${formName}" — ignoring.`)
  }

  return new Response('OK', { status: 200 })
}
