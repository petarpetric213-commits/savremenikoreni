import { createFileRoute } from '@tanstack/react-router'
import { LegalPage, LegalH2, LegalP } from '@/components/LegalPage'

export const Route = createFileRoute('/povracaj-i-zamena')({
  component: PovracajPage,
})

// NOTE FOR THE SITE OWNER: generic template based on the general right-of-
// withdrawal rules under the Zakon o zaštiti potrošača (distance selling).
// Not legal advice — please confirm the exact return-shipping-cost policy
// and any custom-order exceptions before publishing, ideally with a lawyer
// or accountant familiar with Serbian consumer protection law.

function PovracajPage() {
  return (
    <LegalPage label="Pravne informacije" title="Povraćaj i zamena">
      <LegalP>
        Trudimo se da svaki kupac bude zadovoljan svojom porudžbinom. Ova
        stranica objašnjava kako funkcioniše povraćaj i zamena za komade
        kupljene preko sajta Savremeni Koreni.
      </LegalP>

      <LegalH2>Pravo na odustanak od ugovora (14 dana)</LegalH2>
      <LegalP>
        Za standardne komade iz kolekcije, kao potrošač imate pravo da
        odustanete od kupovine u roku od 14 dana od dana prijema robe, bez
        obaveze navođenja razloga, u skladu sa Zakonom o zaštiti potrošača.
        O odluci o odustanku obavestite nas pisanim putem (email ili
        WhatsApp) pre isteka tog roka.
      </LegalP>

      <LegalH2>Izuzetak — posebne (custom) porudžbine</LegalH2>
      <LegalP>
        Komadi izrađeni po posebnom zahtevu kupca (prilagođena boja,
        materijal ili dimenzije, dogovoreni unapred) predstavljaju robu
        proizvedenu prema specifikaciji potrošača, na koju se pravo na
        odustanak po zakonu ne primenjuje, osim ako se drugačije dogovorimo.
      </LegalP>

      <LegalH2>Uslovi za povraćaj</LegalH2>
      <LegalP>
        Da bi povraćaj bio prihvaćen, komad treba da bude nekorišćen, u
        originalnom stanju i, ako je moguće, u originalnom pakovanju.
        Troškove vraćanja robe snosi kupac, osim ako je drugačije
        naznačeno pri porudžbini. [Ovde precizirati da li prodavac
        refundira i poštarinu, i u kom roku se vrši povraćaj novca —
        zakonski rok je najkasnije 14 dana od prijema obaveštenja o
        odustanku.]
      </LegalP>

      <LegalH2>Zamena</LegalH2>
      <LegalP>
        Ako komad ne odgovara veličini ili ste promenili mišljenje o boji,
        rado ćemo razmotriti zamenu za drugi dostupan komad — javite nam se
        putem WhatsApp-a ili email-a u roku od 14 dana od prijema.
      </LegalP>

      <LegalH2>Oštećena ili neispravna roba</LegalH2>
      <LegalP>
        Ako stigne oštećen ili neispravan komad, kontaktirajte nas što pre
        sa fotografijom oštećenja — snosimo odgovornost i organizujemo
        besplatnu zamenu ili povraćaj novca u skladu sa zakonom o
        saobraznosti robe ugovoru.
      </LegalP>

      <LegalH2>Kako pokrenuti povraćaj ili zamenu</LegalH2>
      <LegalP>
        Pišite nam na savremenikoreni@gmail.com ili WhatsApp 060 331 8319,
        sa brojem porudžbine i kratkim opisom razloga.
      </LegalP>
    </LegalPage>
  )
}
