import type { ReactNode } from 'react'

export function LegalPage({ label, title, children }: { label: string; title: string; children: ReactNode }) {
  return (
    <main>
      <section style={{ background: '#F3EDE3', padding: '4rem 0 2.5rem', textAlign: 'center' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="section-label mb-3">{label}</div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 500, color: '#1E3A2F' }}>
            {title}
          </h1>
          <div className="line-gold" style={{ margin: '1.25rem auto 0' }} />
        </div>
      </section>

      <section style={{ background: '#FAF7F2', padding: '4rem 0' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div
            style={{
              maxWidth: '720px',
              margin: '0 auto',
              color: '#4A4A4A',
              fontSize: '0.9375rem',
              lineHeight: '1.85',
            }}
          >
            {children}
          </div>
        </div>
      </section>
    </main>
  )
}

export function LegalH2({ children }: { children: ReactNode }) {
  return (
    <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.375rem', fontWeight: 500, color: '#1E3A2F', marginTop: '2.5rem', marginBottom: '0.875rem' }}>
      {children}
    </h2>
  )
}

export function LegalP({ children }: { children: ReactNode }) {
  return <p style={{ marginBottom: '1rem' }}>{children}</p>
}
